"""Rebuild all literature-derived tables and figures; no network or model calls."""
from pathlib import Path
import csv
import json
import re
from decimal import Decimal
from collections import Counter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "evidence"
GEN = ROOT / "generated"
FIG = ROOT / "figures"
GEN.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
def read(name):
    with (DATA / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))
def tex(s):
    mapping = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
               "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
               "ő": r"\H{o}", "–": "--", "—": "---"}
    return "".join(mapping.get(c, c) for c in str(s))
def write(name, value):
    (GEN / name).write_text(value, encoding="utf-8")

cohorts = read("cohorts.csv")
records = read("discoveries.csv")
certificate_codes = {"finite_witness", "construction_family", "existence_argument", "general_derivation", "mixed"}
status_codes = {"affirmation", "refutation", "partial_progress", "unresolved"}
assert all(r["certificate_class"] in certificate_codes for r in records)
assert all(r["resolution_status"] in status_codes for r in records)
bibkeys = set()
for path in ROOT.glob("references*.bib"):
    bibkeys.update(re.findall(r"@\w+\{([^,]+),", path.read_text(encoding="utf-8")))
for row in records + read("benchmark_metrics.csv") + cohorts:
    assert row["source_key"] in bibkeys, ("Missing source key", row["source_key"])
assert len({r["record_id"] for r in records}) == len(records), "Duplicate record ID"
assert len({r["cohort_id"] for r in cohorts}) == len(cohorts), "Duplicate cohort ID"
for c in cohorts:
    for k in ("n_total", "n_addressed", "n_resolved", "n_unresolved",
              "n_proof", "n_disproof", "n_mixed_or_other"):
        c[k] = int(c[k])
        assert c[k] >= 0, (c["cohort_id"], k)
    assert c["n_resolved"] + c["n_unresolved"] == c["n_total"]
    assert c["n_proof"] + c["n_disproof"] + c["n_mixed_or_other"] == c["n_addressed"]
    sub = [r for r in records if r["cohort_id"] == c["cohort_id"]
           and r.get("is_primary_record", "1") == "1"]
    if sub:
        assert len(sub) == c["n_addressed"], (c["cohort_id"], len(sub), c["n_addressed"])
        counts = Counter(r["outcome_class"] for r in sub)
        assert counts["proof"] == c["n_proof"], (c["cohort_id"], counts)
        assert counts["disproof"] == c["n_disproof"], (c["cohort_id"], counts)

short = {
 "gemini700_v3": "Gemini Erdős v3",
 "openai_ten_selected": "OpenAI selected ten",
 "epoch68_fixed": "Erdős fixed Astra",
 "epoch68_extra": "Erdős all Astra attempts",
 "epoch_open_20260919": "Open registry (19 Sep.)",
}
qualifier = {
 "gemini700_v3": "700 screened; 13 addressed",
 "openai_ten_selected": "10 selected entries; attempts unknown",
 "epoch68_fixed": "68 statements; one attempt each",
 "epoch68_extra": "68 statements; unequal repeats",
 "epoch_open_20260919": "49 active tasks; 8 solved entries",
}
rows = []
for c in cohorts:
    rows.append(tex(short[c["cohort_id"]]) + " & " + " & ".join(str(c[k]) for k in
      ("n_total", "n_addressed", "n_proof", "n_disproof", "n_mixed_or_other")) +
      r" \\" + "\n")
write("cohort_table.tex",
 r"""\begin{table}[t]
\centering\small
\caption{Separate bounded cohorts. A = affirmative result, R = refutation,
O = mixed/other; the target and scope qualifications in the text are essential.
The addressed column includes partial and literature-based Gemini results.
The two Erd\H{o}s rows overlap and must not be added.}
\label{tab:cohorts}
\begin{tabularx}{\linewidth}{@{}Yrrrrr@{}}
\toprule
Cohort & Total & Addressed & A & R & O\\
\midrule
""" + "".join(rows) + r"""\bottomrule
\end{tabularx}
\end{table}
""")

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                     "pdf.fonttype": 42, "axes.spines.top": False,
                     "axes.spines.right": False})
colors = ["#2f6589", "#b7503d", "#a4aab2"]
fig, ax = plt.subplots(figsize=(7.2, 3.3), layout="constrained")
y = np.arange(len(cohorts))
left = np.zeros(len(cohorts))
for key, label, color in zip(("n_proof", "n_disproof", "n_mixed_or_other"),
                            ("Affirmative result", "Refutation", "Mixed / other"), colors):
    values = np.array([c[key] for c in cohorts])
    ax.barh(y, values, left=left, color=color, height=.55, label=label)
    for i, v in enumerate(values):
        if v:
            ax.text(left[i] + v/2, i, str(v), ha="center", va="center",
                    color="white" if color != colors[2] else "#182028", weight="bold")
    left += values
ax.set_yticks(y, [short[c["cohort_id"]] + "\n" + qualifier[c["cohort_id"]] for c in cohorts])
ax.invert_yaxis()
ax.set_xlabel("Reported addressed / solved entries (not a shared success-rate denominator)")
ax.set_xticks(range(0, max(int(v) for v in left) + 1))
ax.grid(axis="x", alpha=.12)
ax.set_axisbelow(True)
ax.legend(ncol=3, loc="lower center", bbox_to_anchor=(.47, 1.02), frameon=False, fontsize=8)
fig.savefig(FIG / "cohort_counts.pdf", bbox_inches="tight",
            metadata={"CreationDate": None, "ModDate": None})
fig.savefig(FIG / "cohort_counts.png", dpi=180, bbox_inches="tight")
plt.close(fig)

milestones = sorted(read("progress_milestones.csv"), key=lambda r: r["date"])
fig, ax = plt.subplots(figsize=(7, 7.2))
fig.subplots_adjust(left=.02, right=.99, top=.97, bottom=.03)
n = len(milestones)
ax.plot([.18,.18],[-.3,n-.7], color="#b5c3cf", lw=2, zorder=1)
for i,r in enumerate(milestones):
    ax.scatter(.18,i,s=35,color="#2f6589",zorder=2)
    ax.text(.155,i,r["date"],ha="right",va="center",fontsize=8.5,color="#465461")
    ax.text(.21,i-.12,r["label"],ha="left",va="center",fontsize=9,weight="bold")
    ax.text(.21,i+.19,r["category"],ha="left",va="center",fontsize=8,color="#465461")
ax.set_xlim(0,1)
ax.set_ylim(n-.45,-.5)
ax.axis("off")
fig.savefig(FIG/"progress_timeline.pdf",bbox_inches="tight",
            metadata={"CreationDate": None, "ModDate": None})
fig.savefig(FIG/"progress_timeline.png",dpi=180,bbox_inches="tight")
plt.close(fig)
keys = list(dict.fromkeys(r["bibkey"] for r in milestones))
write("progress_table.tex", r"""\begin{figure}[p]
\centering
\includegraphics[width=.98\linewidth]{progress_timeline.pdf}
\caption{Dated progress timeline through 19 September 2026. Rows are ordered,
not spaced by elapsed time. Dates denote public reports or designated snapshot
revisions, not necessarily the day of discovery. Source details and numerical
claims are in the text and the milestone ledger \citep{""" + ",".join(keys) +
 r"""}. The Jacobian and Navier--Stokes entries are reported resolutions;
publication, formal verification, and community acceptance remain distinct.}
\label{fig:timeline}
\end{figure}
""")
workflows = read("workflow_comparison.csv")
wr = []
for r in workflows:
    wr.append(tex(r["workflow"]) + r"\newline\emph{" + tex(r["example"]) + r"}\citep{" +
       r["source_key"] + "} & " + tex(r["human_input"]) + " & " +
       tex(r["feedback"]) + " & " + tex(r["interpretation"]) + r"\\" + "\n")
write("workflow_table.tex",
 r"""\begin{table}[t]
\centering\small
\caption{Documented workflow patterns. Model roles, source URLs, and the
complete extraction are in the supplement. These are examples, not controlled
comparisons of workflow effectiveness.}
\label{tab:workflows}
\begin{tabularx}{\linewidth}{@{}YYYY@{}}
\toprule
Workflow / example & Human contribution & Feedback & Interpretation\\
\midrule
""" + "".join(wr) + r"""\bottomrule
\end{tabularx}
\end{table}
""")
# Detailed compact ledger: certificate/outcome categories stay separate.
rrows = []
last_cohort = None
for r in records:
    if r["cohort_id"] != last_cohort:
        rrows.append(r"\multicolumn{4}{@{}l}{\textbf{" + tex(short[r["cohort_id"]]) + r"}}\\[2pt]" + "\n")
        last_cohort = r["cohort_id"]
    suffix = " (detail only)" if r.get("is_primary_record", "1") == "0" else ""
    rrows.append(tex(r["item_title"] + suffix) + " & " +
                 tex(r["outcome_class"].replace("_"," ")) + " & " +
                 tex(r.get("resolution_status", "NA").replace("_", " ")) + " & " +
                 tex(r["certificate_class"].replace("_"," ")) + r"\\" + "\n")
write("discovery_ledger.tex",
 r"""\small
\begin{longtable}{@{}L{.34\linewidth}L{.12\linewidth}L{.20\linewidth}L{.25\linewidth}@{}}
\caption{Record-level direction, resolution status, and certificate codes.
Source passages, verification, workflow, and sensitivity notes are in
discoveries.csv. Detail-only rows do not enter the ten-entry denominator.
The fixed and extended Erd\H{o}s rows repeat two mathematical results.}
\label{tab:ledger}\\
\toprule Record & Direction & Status & Certificate\\ \midrule\endfirsthead
\toprule Record & Direction & Status & Certificate\\ \midrule\endhead
""" + "".join(rrows) + r"""\bottomrule\end{longtable}\normalsize
""")
summary = {
 "cohorts": len(cohorts), "discovery_records": len(records),
 "milestones": len(milestones), "workflow_examples": len(workflows),
 "counts": [{k:c[k] for k in ("cohort_id", "n_total", "n_addressed",
              "n_proof", "n_disproof", "n_mixed_or_other")} for c in cohorts],
 "interpretation": "No pooling; selected and overlapping cohorts are not independent trials.",
}
metrics = {r["metric_id"]: r for r in read("benchmark_metrics.csv")}
summary["brokenarxiv_prompt_score_change_percentage_points"] = str(
    Decimal(metrics["brokenarxiv_gemini31_pd"]["reported_value"]) -
    Decimal(metrics["brokenarxiv_gemini31"]["reported_value"]))
repeat_success = Counter()
for r in records:
    if r["cohort_id"] == "epoch68_extra":
        match = re.fullmatch(r"(\d+)_total_(\d+)_successful", r["run_or_attempt_count"])
        assert match, r["record_id"]
        repeat_success[r["outcome_class"]] += int(match.group(2))
summary["nonuniform_repeated_successes_not_comparative"] = dict(repeat_success)
summary["primary_record_count_not_unique_mathematical_results"] = sum(r["is_primary_record"] == "1" for r in records)
write("reproduction_summary.json", json.dumps(summary, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(summary, indent=2, ensure_ascii=True))
