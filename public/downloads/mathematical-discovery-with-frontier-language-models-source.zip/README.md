# Mathematical Discovery with Frontier Language Models

Original LaTeX manuscript, figures, bibliography, and reproducible evidence supplied by Jinze Zhao.

Compile main.tex using Tectonic, or pdflatex followed by bibtex and two more pdflatex runs. The figures and tables are already included.

To regenerate the descriptive figures and tables, install requirements.txt and run python scripts/reproduce.py. Evidence CSVs and coding notes are in evidence/.

The source retains the original commented-out prompt-card appendix. The blog version omits the sentence referring to that excluded appendix.
