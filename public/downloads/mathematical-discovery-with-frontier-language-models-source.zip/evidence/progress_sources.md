# Progress-section source ledger

Snapshot date: 2026-09-19. Claims below were checked against primary papers,
official benchmark documentation, released repositories, or first-party model
reports. Company reports are treated as claims by the reporting organization,
not as independent acceptance.

| Bibkey | Primary source and version | Evidence used | Required caveat |
|---|---|---|---|
| `hubert2026alphaproof` | Hubert et al., *Nature* 651, online 2025-11-12, version of record 2026-03-13 | AlphaProof 3/5 non-geometry; combined 4/6 and 28/42 | Human formalization and translation; multi-day compute; known-solution competition |
| `deepmind2025imo` | Google DeepMind, 2025-07-21 | Advanced Deep Think 5/6 and 35/42 in 4.5 hours; IMO coordinators graded solutions | Special unreleased model; IMO review covered answers, not system or protocol |
| `novikov2025alphaevolve` | Google DeepMind white paper, 2025-05 | Evolutionary code generation with automated evaluators; initial “over 50,” ~75% rediscovery, 20% improvement | Exact denominator and trial budget absent; applies to verifier-friendly constructions |
| `georgiev2025mathexploration` | arXiv:2511.02864v3, 2025-12-22 | Later 67-problem mixed solved/unsolved portfolio; positive and negative results | Do not apply the earlier 75%/20% figures to 67; service is not released |
| `feng2026aletheia` | arXiv:2602.10177v3, 2026-03-06 | Aletheia architecture and autonomy taxonomy | Advanced model is unreleased; cases do not form a controlled success rate |
| `feng2026erdos` | arXiv:2601.22401v3, 2026-02-05 | 700 screened; 4 seemingly novel results (2 full, 2 partial), 4 independent rediscoveries, and 5 literature identifications | Landing-page abstract still gives 5 novel and 8 prior-solution cases, conflicting with the v3 PDF's 4/9 split after Erdős-935 was reclassified; use the versioned PDF; substantial human review |
| `abouzaid2026firstproof` | arXiv:2606.18119v1, 2026-06-16 | 10 problems, 4 systems, 39 outputs, 30 experts, 2–3 referees/output; union passing coverage 7/10 | 7/10 is not a single-model score; systems and costs differ; Batch 1 was not formally graded |
| `epoch2026frontiermathv2` | Epoch AI v2 page, released 2026-06-12 | 338 current problems; errors addressed in 42% of the earlier set, including removals; 295 base + 43 Tier 4 | Do not describe all affected problems as corrected and retained; older 180/300/350-item scores are not directly comparable; OpenAI access conflict must be disclosed |
| `epoch2026frontiermathopen` | Epoch live ledger, accessed 2026-09-19 | 49 active: 41 unsolved, 4 AI, 4 human+AI; categories and changelog | Dynamic set, heterogeneous attempts, failures no longer displayed, attribution policy changed 2026-09-16 |
| `deepmind2026formalconjectures` | arXiv:2605.13171v1 and tagged repository | 2,615 Lean statements; 1,029 open; 836 solved autoformalization targets | Kernel checking does not guarantee fidelity of informal-to-formal statement |
| `wang2026horizonmath` | arXiv:2603.15617v2, 2026-09-10 | 113 predominantly unsolved problems; six reported novel advances; most models under 10% | Computationally checkable slice of mathematics; “candidate contribution” still needs mathematical contextualization |
| `adamczewski2026frontiermatherdos` | Epoch report and 12-page paper, 2026-09-01 | Fixed run: 68 statements from 65 Erdős problem numbers; Astra 2/68, four others 0/68. Broader campaign: Astra solved 5/68 at least once; 269 completed attempts covered 59 of the 63 never-solved statements, with repeat counts for solved targets tabulated separately; >$220k over all attempts | Do not infer a full attempt denominator from 269; the broader campaign is not the benchmark score; 18 AI-formalized statements awaited Lean-expert review |
| `alon2026unitdistance` / `openai2026unitdistance` | arXiv:2605.20695v1 and OpenAI report, 2026-05-20 | Human-verified digest of AI-generated disproof | Internal model; collection denominator, attempts, and compute undisclosed |
| `ulam2026jacobian` / `anthropic2026jacobian` | Public mathematical manuscript, 2026-07-20; Anthropic retrospective, 2026-07-28 | Manuscript verifies the explicit three-variable certificate and stabilization; Anthropic attributes the resolution to Claude Fable 5 | Manuscript has no named author; no full discovery report, transcript, budget, or controlled protocol; two-variable case remains open |
| `openai2026tenadvances` | OpenAI report/paper, 2026-08-01; paper updated 2026-08-06; Lean repository | Ten selected proofs, disproofs, and bounds; internal Astra; public manuscripts/certificates | No problem denominator, failed-run count, or independent peer-review status |
| `anthropic2026flt` | Anthropic report and public repository, 2026-09-04 | 11 days, ~6B output tokens, 13M Lean lines, 30,300 intermediate theorems; repository documents Lean, Comparator, and an independent kernel | Formalization of a known proof, not new discovery; occasional human direction |
| `openai2026navierstokes` | OpenAI paper/report and Lean repository, 2026-09-08, update 2026-09-10 | Forced finite-time singularity, Clay alternatives C/D; agent and compute figures | Internal unreleased model; forced formulation; very recent and not yet settled community acceptance; no prize claim |

## Interpretation rules used in the section

1. Keep benchmark solution, rediscovery, bound/construction improvement,
   research resolution, and formalization as separate labels.
2. Report the evaluated denominator and sampling unit whenever one exists.
3. Treat best-of-many or variable-budget runs separately from fixed-protocol
   scores.
4. Separate kernel correctness from statement fidelity, novelty, importance,
   and community acceptance.
5. A public proof artifact does not imply that the model, scaffold, search
   budget, or discovery process is public.
6. Use “reported” for September 2026 lab announcements whose broad mathematical
   review was still in progress at the snapshot date.
