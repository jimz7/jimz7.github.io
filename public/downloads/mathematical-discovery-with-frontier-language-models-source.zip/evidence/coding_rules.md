# Coding rules and data dictionary

Literature cutoff: 19 September 2026. Primary-source rechecking continued on 20 September. This is a targeted, retrospectively assembled extraction, not a preregistered systematic review or a random sample of mathematical research.

## Files and units

- cohorts.csv: four bounded source collections, five rows because FrontierMath Erdős fixed and expanded regimes remain distinct.
- discoveries.csv: one positive-result record per source item and regime, plus two audit-only OpenAI entry10 subrecords. Filter is_primary_record=1 before counting.
- benchmark_metrics.csv: reported cells, not reconstructed individual responses. NA means unreported/inapplicable, never zero. Percentages retain source precision.
- search_log.csv: source routes and recheck decisions, not a complete browser-history export.
- classification_audit.md: disagreements, corrections, sensitivities, and review scope.

The legacy n_resolved field means positive/accepted/meaningfully-addressed entries under that row's scope rule. For Gemini it includes partial answers and rediscovery; it is NOT a count of wholly resolved, novel problems. n_unresolved=n_total-n_resolved is the complementary count with no reported positive entry, not a list of failed runs. The showcase has no attempted-problem denominator. Registry counts are dated active entries, not attempts.

## Independent coding axes

### Resolution status

The resolution_status field codes affirmation (the announced positive result established), refutation (the target conjecture negated), partial_progress (a subquestion or weaker result), or unresolved. Scope follows each record's notes. A partial negative answer can have resolution_status=partial_progress and outcome_class=disproof.

### Direction

outcome_class uses proof for an affirmative theorem, disproof for negation of the target conjecture, construction for an explicit-object or record task without a natural polarity comparison, and other_resolution for open-ended estimation. It is not initial strategy and is not inferred from task tags. OpenAI's Ramsey theorem is proof under announced-direction coding, with finite-exponential-growth refutation as sensitivity. Gemini1089 is open-ended limit evaluation, with affirmative coding as sensitivity.

### Certificate

- finite_witness: finite explicit object with properties checked in the stated regime. This does not assert a cheap check or a check rerun by this survey.
- construction_family: explicitly described infinite object or parameterized family, including constructions requiring a general proof. A single infinite group belongs here rather than being called finite.
- existence_argument: theorem-mediated or nonconstructive existence without a supplied decisive finite object.
- general_derivation: general proof or reduction, possibly using cited results.
- mixed: substantively different components or a mixture of existential and constructive steps.

Classes describe the accepted source's representation, not all equivalent formulations. Moving a cited existence theorem from general_derivation to existence_argument can be reasonable; such ambiguity does not alter directional counts.

### Workflow, autonomy, verification

workflow_class records documented process: fixed agent, nonuniform repeated agent, literature retrieval, human-guided work, or model argument followed by human preparation/formalization. autonomy_class retains source-attributed autonomy separately. Neither is inferred from a final model-produced certificate.

verified_status is a descriptive evidence string, not a quality score. Distinguish expert review, Comparator acceptance, bespoke executable acceptance, posted manuscript, and company-reported formal artifacts. This survey did not rerun every external Lean project or regenerate discoveries. Registry acceptance is not automatically a complete independent proof.

## Inclusion and sensitivity

1. Gemini: exactly13positive entries in v3 PDF Table1;700inputs only as deployment denominator. Use PDF4novel/9prior, not stale landing-page5/8. The four apparently novel answers include two partials.
2. OpenAI: ten numbered entries once each. Audit detail10a/10b has is_primary_record=0. Narrow disproof IDs3,4,10; broad sensitivity additionally flags9, yielding4/10 without becoming a strategy-choice estimate.
3. FrontierMath:68formal statements,65ErdősIDs. Keep regimes separate but do not sum overlapping74/126 for unique discoveries. Union has five positive targets. Repeated runs are not new discoveries.
4. Registry:49active entries and eight positives at cutoff, not stale50headline. Counterexample tags overlap and do not define outcomes. Committee outcome is affirmative.
5. Do not append discoveries from other reports to these denominators.
6. Do not pool benchmark metrics with discovery composition or merge monthly BrokenArXiv rubrics.
7. Never reconstruct integer counts from rounded percentages. The71.0−18.5difference is a percentage-point difference, not a response count.
8. No50%null or binomial preference test is used without matched opportunities and a task distribution.

## Reproduction limits

Build scripts validate primary counts and directional sums and generate tables/figures. CSVs are curated extraction, not raw model traces; observations need not be independent. Source versions and this audit take precedence over changed live metadata. Search-log access dates may be after cutoff, but no post-cutoff mathematical result is included.
