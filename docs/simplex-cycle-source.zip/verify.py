"""Exact finite checks for the simplex-cycle manuscript; standard library only.

Run: python verify.py
This is not a formal proof checker and does not replace the all-period proof.
"""
from fractions import Fraction as Q
import json


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def dot(x, y):
    return sum((a * b for a, b in zip(x, y)), Q(0))


def sub(x, y):
    return [a - b for a, b in zip(x, y)]


def a(c):
    return (1 - c) * (4 * c * c + Q(18, 5) * c + Q(7, 5))


def run():
    x = [[Q(int(i == j)) - Q(1, 5) for j in range(5)] for i in range(5)]
    g = [[2 * x[i][j] + Q(7, 20) * (x[(i + 1) % 5][j] - x[(i - 1) % 5][j])
          for j in range(5)] for i in range(5)]
    v = [[(3 * x[i][j] - g[i][j]) / 2 for j in range(5)] for i in range(5)]
    projection = []
    interpolation = []
    values = []
    for i in range(5):
        p_row, i_row = [], []
        for j in range(5):
            value = dot(sub(x[i], v[i]), sub(v[j], v[i]))
            require(value <= 0, f"projection ({i}, {j})")
            if i != j:
                require(value < 0, f"strict projection ({i}, {j})")
            p_row.append(str(value))
            dx, dg = sub(x[i], x[j]), sub(g[i], g[j])
            rhs = dot(g[j], dx) + dot(dx, dx) / 2 + dot(sub(dg, dx), sub(dg, dx)) / 4
            require(rhs <= 0, f"interpolation ({i}, {j})")
            i_row.append(str(-rhs))
        projection.append(p_row)
        interpolation.append(i_row)
        value = dot(x[i], x[i]) / 2 + dot(sub(x[i], v[i]), sub(x[i], v[i]))
        require(value == Q(529, 800), "cycle value")
        values.append(str(value))

    coeffs = [Q(1, 5), Q(-1, 10), Q(16, 5), Q(-3, 2), Q(1, 5), Q(-1)]
    require(sum(coeffs) == 1, "translation consistency")
    for t in range(5, 10):
        actual = [sum(coeffs[k] * x[(t - k) % 5][j] for k in range(6))
                  - 2 * g[(t - 2) % 5][j] for j in range(5)]
        require(actual == x[(t + 1) % 5], f"recurrence, residue {t % 5}")

    expected_endpoints = [(Q(7, 8), Q(609, 640)), (Q(-7, 8), Q(315, 128)),
                          (Q(-9, 10), Q(133, 50)), (Q(-19, 20), Q(6201, 2000))]
    for point, expected in expected_endpoints:
        require(a(point) == expected, f"endpoint {point}")
    lower_bounds = {
        "middle": Q(49, 100) * Q(12, 25) ** 2 + Q(28, 15) * Q(12, 25) - 1,
        "left_near": Q(9, 20) ** 2 + Q(49, 100) * Q(2, 5) ** 2 + Q(28, 15) * Q(2, 5) - 1,
        "left_far": Q(33, 50) ** 2 + Q(49, 100) * Q(3, 10) ** 2 + Q(28, 15) * Q(3, 10) - 1,
    }
    expected_bounds = {"middle": Q(139, 15625), "left_near": Q(827, 30000), "left_far": Q(397, 10000)}
    require(lower_bounds == expected_bounds, "barrier arithmetic")
    require(all(z > 0 for z in lower_bounds.values()), "strict positivity")
    require(Q(15, 64) > Q(12, 25) ** 2, "middle sine bound")
    require(Q(39, 400) > Q(3, 10) ** 2, "far-left sine bound")
    require(Q(19, 100) > Q(2, 5) ** 2, "near-left sine bound")
    require(Q(315, 128) > Q(49, 20), "near-left a bound")
    require(18 ** 2 > 7 ** 2 * 5, "cotangent comparison")
    require(a(Q(-1)) == Q(18, 5), "period two")
    require(a(Q(-1, 2)) == Q(9, 10), "period three")
    require(a(Q(0)) == Q(7, 5), "period four")
    require(((Q(7, 5) - 1) * (Q(7, 5) - 3) + Q(49, 100)) / 2 + Q(7, 10) == Q(5, 8),
            "period-four obstruction")
    return {
        "status": "PASS: all finite checks used exact rational arithmetic",
        "projection_inner_products": projection,
        "interpolation_slacks": interpolation,
        "cycle_values": values,
        "barrier_lower_bounds": {k: str(v) for k, v in lower_bounds.items()},
        "scope": "Finite arithmetic only; see the manuscript for the proof excluding all periods.",
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
