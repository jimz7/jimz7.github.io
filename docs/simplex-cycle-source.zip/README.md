# Simplex-cycle research draft

This project uses the supplied blank LaTeX article template.

Compile `main.tex` with pdfLaTeX, run BibTeX on `main`, then run pdfLaTeX twice more.
The sibling `paper.tex` is a self-contained equivalent for the built-in editor.

Run `python verify.py` for exact rational checks (Python standard library only).
These checks supplement the written proof; they do not constitute formal verification.

The target is the unrestricted general stationary-method conjecture from 2023,
numbered Conjecture 7.1 in arXiv:2307.11291v2. The result does not settle the
heavy-ball-specific conjecture or a version restricted to quadratically stable methods.
The manuscript has not undergone independent specialist or peer review.

The supplied exact-arithmetic verification passed. A separate AI-agent proof audit
found no substantive mathematical defect; this is not external peer review.
The built-in LaTeX compiler could not run because of an environment error:
"Unable to find standard directories for platform". Compilation and rendered
layout are therefore unverified, and no compiled PDF is included.
