"""Exact finite diagnostics for the manuscript. Python 3, standard library only.

These computations supplement, and do not replace, the mathematical proofs.
Run: python verify.py
"""
from fractions import Fraction as Q
from itertools import permutations, product
from pathlib import Path
import json


def parameters(weights):
    assert weights and min(weights) >= 1 and sum(weights) % 2 == 0
    b = sum(weights) // 2
    w = 128 * b**3
    target = w + b
    center = Q(target) - Q(b*b, 2*w)
    deadline = center + Q(1, 4*w)
    prices = [Q(a) - Q(a*a, 2*w) for a in weights]
    gains = [Q(a, w) for a in weights]
    return b, w, target, center, deadline, prices, gains


def sorted_dp(weights):
    b, w, target, _, _, _, _ = parameters(weights)
    states = {0: Q(0)}
    for a in sorted(weights):
        price = Q(a) - Q(a*a, 2*w)
        new = states.copy()
        for s, elapsed in states.items():
            candidate = elapsed + price / (1 + Q(s, w))
            if s+a not in new or candidate < new[s+a]:
                new[s+a] = candidate
        states = new
    return min(elapsed + Q(target)/(1 + Q(s, w))
               for s, elapsed in states.items())


def audit_orders(weights):
    b, w, target, center, deadline, prices, gains = parameters(weights)
    multiplier = 2*target+1
    assert all(0 < p < target < multiplier*p for p in prices)
    assert all(Q(23,20)*p > target*x for p, x in zip(prices,gains))
    count = 0
    best = None
    partition = False
    max_scaled_remainder = Q(0)
    for length in range(len(weights)+1):
        for order in permutations(range(len(weights)), length):
            s = 0
            purchase_time = Q(0)
            purchase_remainder = Q(0)
            for i in order:
                a = weights[i]
                step = prices[i]/(1 + Q(s,w))
                rem = Q(a*s*s, w*(w+s)) + Q(a*a*s, 2*w*(w+s))
                assert step == a - Q(a*s, w) - Q(a*a, 2*w) + rem
                purchase_time += step
                purchase_remainder += rem
                s += a
            wait = Q(target)/(1 + Q(s,w))
            wait_remainder = Q(s*s*(b-s), w*(w+s))
            assert purchase_time == s-Q(s*s,2*w)+purchase_remainder
            assert wait == target-s+Q(s*s-b*s,w)+wait_remainder
            assert 0 <= purchase_remainder <= Q(s**3,w*w) <= Q(8*b**3,w*w)
            assert abs(wait_remainder) <= Q(4*b**3,w*w)
            remainder = purchase_remainder + wait_remainder
            elapsed = purchase_time+wait
            assert elapsed == center+Q((s-b)**2,2*w)+remainder
            assert abs(remainder) <= Q(3,32*w)
            assert (elapsed <= deadline) == (s == b)
            partition |= s == b
            max_scaled_remainder = max(max_scaled_remainder,abs(remainder)*w)
            if best is None or elapsed < best:
                best = elapsed
            count += 1
    assert (best <= deadline) == partition
    assert sorted_dp(weights) == best
    return count, max_scaled_remainder


def fixed_multiplier_dp(weights):
    """Exhaustive two-type count DP; repeats are explicitly allowed."""
    assert len(weights) == 2
    _, _, target, _, _, prices, gains = parameters(weights)
    alpha = Q(23,20)
    copy_prices = []
    for initial in prices:
        row = []
        price = initial
        while price < target:
            row.append(price)
            price *= alpha
        copy_prices.append(row)
    n0, n1 = [len(row) for row in copy_prices]
    table = [[None]*(n1+1) for _ in range(n0+1)]
    table[0][0] = Q(0)
    best = Q(target)
    for c0 in range(n0+1):
        for c1 in range(n1+1):
            if c0 == 0 and c1 == 0:
                pass
            else:
                candidates = []
                if c0:
                    prior_rate = 1+(c0-1)*gains[0]+c1*gains[1]
                    candidates.append(table[c0-1][c1]+copy_prices[0][c0-1]/prior_rate)
                if c1:
                    prior_rate = 1+c0*gains[0]+(c1-1)*gains[1]
                    candidates.append(table[c0][c1-1]+copy_prices[1][c1-1]/prior_rate)
                table[c0][c1] = min(candidates)
            final_rate = 1+c0*gains[0]+c1*gains[1]
            best = min(best, table[c0][c1]+Q(target)/final_rate)
    assert best == sorted_dp(weights)
    return (n0+1)*(n1+1)


def main():
    instances = orders = 0
    largest_scaled_error = Q(0)
    for length in range(1,5):
        for weights in product(range(1,5), repeat=length):
            if sum(weights) % 2:
                continue
            count, error = audit_orders(weights)
            orders += count
            instances += 1
            largest_scaled_error = max(largest_scaled_error,error)
    fixed_instances = fixed_states = 0
    for weights in product(range(1,4), repeat=2):
        if sum(weights) % 2:
            continue
        fixed_states += fixed_multiplier_dp(weights)
        fixed_instances += 1
    report = {
        "status": "all exact checks passed",
        "arithmetic": "Python fractions.Fraction; no floating-point calculations",
        "even_total_integer_instances": instances,
        "ordered_subsets_checked": orders,
        "largest_observed_W_times_abs_remainder": str(largest_scaled_error),
        "proved_upper_bound_W_times_abs_remainder": "3/32",
        "fixed_23_over_20_instances": fixed_instances,
        "fixed_multiplier_count_states_including_repeats": fixed_states,
        "checks": ["exact purchase identity", "exact waiting identity",
                   "uniform remainder", "deadline equivalence",
                   "sorted DP versus all orders", "full count DP versus no repeats"],
        "limitation": "Finite diagnostics, not a formal proof or a novelty certification"
    }
    path = Path(__file__).with_name("verification_report.json")
    path.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
