# Research manuscript

**Title:** Zero Initial Capital Does Not Make Continuous-Time Incremental Production Easy

This draft uses the supplied `blank_latex_template.zip`: its article class, preamble, section-file structure, theorem environments, bibliography style, and page layout have been retained.

The paper presents a proof of the increasing-cost Cookie Clicker hardness conjecture stated in Section 4 of Demaine et al., first posted in August 2018 and published in *Graphs and Combinatorics* 36 (2020), 269–302. It further proves NP-completeness for every fixed rational price multiplier greater than one, including 1.15. Inputs have positive rational prices and rate increases, the item count varies, initial balance is zero, and initial production rate is one. The objective concerns unspent balance.

The core reduction was independently checked during preparation. An executable exact-rational verifier accompanies the proof. No prior resolution of the exact conjecture was found in the literature search, but novelty is not certified and the manuscript has not been externally peer reviewed or formally verified. Author details are intentionally omitted; add the appropriate human authorship before any submission.

## Files

- `main.tex`: entry point.
- `preamble.tex`: the supplied template's preamble.
- `sections/`: full manuscript, including detailed proofs and scope notes.
- `references.bib`: bibliography.
- `verify.py`: independent finite diagnostics, using Python's standard library.
- `verification_report.json`: output of the verifier.

## Compile

From this directory:

```text
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Alternatively:

```text
tectonic main.tex
```

Run the exact finite checks with:

```text
python verify.py
```

The compiled PDF is provided separately as `cookie_clicker_hardness.pdf`. The complete source folder is also packaged in `cookie_clicker_latex_source.zip`.
