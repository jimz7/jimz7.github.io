# Completed article template

Entry point: `main.tex`. Compile with the standard pdfLaTeX/BibTeX sequence or Tectonic. All figure PDFs and table fragments are included. See the package-level README for experiments and solver use.
