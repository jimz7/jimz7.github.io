from pathlib import Path
import json,csv,sys,statistics
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
HERE=Path(__file__).resolve().parent
PAPER=HERE.parent/'paper';SOLVER=HERE.parent/'solver'
sys.path.insert(0,str(SOLVER))
from domino_fit import Puzzle,Board,solve,verify
data=json.loads((SOLVER/'observed.json').read_text())
results=list(csv.DictReader((SOLVER/'benchmark.csv').open()))
summary=json.loads((SOLVER/'benchmark_summary.json').read_text())
def pick(name,method,mode='up-to-two'):
    return next(r for r in results if r['name']==name and r['method']==method and r['mode']==mode)
def agg(group,method,mode='first'):
    return next(r for r in summary['summary'] if (r['group'],r['method'],r['mode'])==(group,method,mode))

# Independently verify the worked margin vector before writing it into the paper.
p=Puzzle.from_dict(data[2]);b=Board(p);k,reason=b.margins();assert not reason
assert k==tuple([3,2,4,0,0,0,2,0]+[2,1,1,2,3,4,3,2]+[3,3,0,0,2,1,1,1]+[1,1,7,1,2,3,3,0])
fp=PAPER/'sections/invariants.tex'
fp.write_text(fp.read_text().replace('(1,1,7,1,1,3,4,0)','(1,1,7,1,2,3,3,0)'))

fig=PAPER/'figures';fig.mkdir(exist_ok=True)
c=canvas.Canvas(str(fig/'observed8.pdf'),pagesize=(510,280))
ink=HexColor('#173E49');gray=HexColor('#EAF0F2');block=HexColor('#40515A')
sol=solve(p,'bitset',None);assert sol.complete and len(sol.solutions)==1 and verify(p,sol.solutions[0])
for idx,(x0,title,tiles) in enumerate([(24,'PUZZLE',None),(288,'VERIFIED SOLUTION',sol.solutions[0])]):
    step=26;top=239
    c.setFillColor(ink);c.setFont('Helvetica-Bold',10);c.drawString(x0,268,title)
    for j,v in enumerate(p.cols):c.drawCentredString(x0+(j+.5)*step,249,str(v))
    for r,v in enumerate(p.rows):c.drawRightString(x0-9,top-(r+.5)*step-3,str(v))
    for r in range(8):
        for j in range(8):
            c.setFillColor(block if (r,j) in p.blocked else gray)
            c.setStrokeColor(white);c.setLineWidth(.7)
            c.rect(x0+j*step,top-(r+1)*step,step,step,fill=1,stroke=1)
    if tiles:
        for t,r,j in tiles:
            w=step*(2 if t=='H' else 1);h=step*(2 if t=='V' else 1)
            x=x0+j*step;y=top-r*step-h
            c.setFillColor(white);c.setStrokeColor(ink);c.setLineWidth(.85)
            c.roundRect(x+.6,y+.6,w-1.2,h-1.2,2,fill=1,stroke=1)
            c.setStrokeColor(HexColor('#D8E1E4'));c.setLineWidth(.5)
            if t=='H':c.line(x+step,y+4,x+step,y+step-4)
            else:c.line(x+4,y+step,x+step-4,y+step)
            c.setFillColor(ink)
            if t=='V':c.circle(x+step/2,y+1.5*step,3,fill=1,stroke=0)
            else:
                c.circle(x+1.5*step-4,y+step/2+4,2.7,fill=1,stroke=0)
                c.circle(x+1.5*step+4,y+step/2-4,2.7,fill=1,stroke=0)
    c.setFont('Helvetica',8);c.setFillColor(ink)
    c.drawString(x0,13,'6 blocked cells; 58 open cells' if idx==0 else '11 vertical + 18 horizontal pieces')
c.save()

out=[r'\begin{table}[htbp]\centering',r'\caption{Observed boards: exhaustive uniqueness checking (up to two solutions, with exhaustion at one). Times are medians in milliseconds; nodes count recursive search entries, not placements.}',r'\label{tab:observed}',r'\begin{tabular}{lrrrrrr}\toprule',r'Board & Pieces & DFS nodes & Bitset nodes & DFS ms & Bitset ms & Forced\\\midrule']
for d in data:
    name=d['name'];r=pick(name,'residual');s=pick(name,'bitset');n=len(d['rows']);N=n*n-len(d['blocked'])
    out.append(f'{n}$\\times${n} & {N//2} & {r["nodes"]} & {s["nodes"]} & {float(r["median_ms"]):.3f} & {float(s["median_ms"]):.3f} & {s["forced"]}'+r'\\')
out.extend([r'\bottomrule\end{tabular}\end{table}'])
(PAPER/'sections/observed_table.tex').write_text('\n'.join(out))
labels={'residual':'Residual DFS','margins':'List quotas','colored':'Color quotas','bitset':'Bitset quotas'}
out=[r'\begin{table}[htbp]\centering',r'\caption{First-solution timings on generated puzzles. Aggregates are across per-instance medians. The last columns give median search entries and capped instances. Residual-DFS stress times exclude two capped cases and are not directly comparable on an identical denominator.}',r'\label{tab:synthetic}',r'\begin{tabular}{llrrrr}\toprule',r'Set & Method & Median ms & P95 ms & Nodes & Capped\\\midrule']
for group in ('synthetic','stress'):
    for method in labels:
        s=agg(group,method)
        out.append(f'{"60 game-size" if group=="synthetic" else "12 larger"} & {labels[method]} & {s["median_ms"]:.3f} & {s["p95_ms"]:.3f} & {s["median_nodes"]:g} & {s["capped"]}/{s["instances"]}'+r'\\')
    if group=='synthetic':out.append(r'\midrule')
out.append(r'\bottomrule\end{tabular}\end{table}')
(PAPER/'sections/synthetic_table.tex').write_text('\n'.join(out))
out=[r'\begin{table}[htbp]\centering',r'\caption{Up-to-two-solution timing on generated puzzles. A second solution proves nonuniqueness; exhaustion at one proves uniqueness. Censored stress aggregates have the same denominator caveat as Table~\ref{tab:synthetic}.}',r'\label{tab:two}',r'\begin{tabular}{llrrr}\toprule',r'Set & Method & Median ms & P95 ms & Capped\\\midrule']
for group in ('synthetic','stress'):
    for method in labels:
        s=agg(group,method,'up-to-two')
        out.append(f'{"60 game-size" if group=="synthetic" else "12 larger"} & {labels[method]} & {s["median_ms"]:.3f} & {s["p95_ms"]:.3f} & {s["capped"]}/{s["instances"]}'+r'\\')
    if group=='synthetic':out.append(r'\midrule')
out.append(r'\bottomrule\end{tabular}\end{table}')
(PAPER/'sections/two_table.tex').write_text('\n'.join(out))
out=[]
for d in data:
    n=len(d['rows']);p=Puzzle.from_dict(d);s=solve(p,'bitset',None);assert s.complete and len(s.solutions)==1
    rows=','.join(map(str,d['rows']));cols=','.join(map(str,d['cols']))
    out.append(r'\paragraph{'+f'{n}$\\times${n}'+r'.}')
    out.append(r'\['+f'R=({rows}),\\qquad C=({cols}).'+r'\]')
    obstacles=', '.join(f'({a},{b})' for a,b in d['blocked'])
    out.append('Blocked coordinates: '+obstacles+'.')
    for t in ('V','H'):
        starts=', '.join(f'({a+1},{b+1})' for typ,a,b in sorted(s.solutions[0],key=lambda x:(x[1],x[2])) if typ==t)
        out.append('\n'+('Vertical' if t=='V' else 'Horizontal')+' start coordinates: '+starts+'.')
(PAPER/'sections/observed_data.tex').write_text('\n\n'.join(out))
(SOLVER/'example8.json').write_text(json.dumps(data[2],indent=2))
print('Assets written; observed bitset unique-check times:',[pick(d['name'],'bitset')['median_ms'] for d in data])
print('Generated solution multiplicities:', {g:sum(r['solutions']=='2' for r in results if r['group']==g and r['mode']=='up-to-two' and r['method']=='bitset') for g in ('synthetic','stress')})
