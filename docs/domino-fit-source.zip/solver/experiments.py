"""Reproduce correctness checks, planted data, and local timing tables."""
import csv,itertools,json,math,platform,random,statistics,sys,time
from pathlib import Path
from domino_fit import Puzzle,solve,verify
ROOT=Path(__file__).resolve().parent
METHODS=('residual','margins','colored','bitset')

def all_tilings(m,n,blocked):
    free={(r,c) for r in range(m) for c in range(n)}-set(blocked)
    def rec(left,out):
        if not left:
            yield tuple(out);return
        r,c=min(left)
        for typ,pair in [('V',(r+1,c)),('H',(r,c+1))]:
            if pair in left:yield from rec(left-{(r,c),pair},out+[(typ,r,c)])
    return list(rec(free,[]))

def clues(m,n,tiles):
    rr=[0]*m;cc=[0]*n
    for t,r,c in tiles:
        if t=='V':rr[r]+=1;cc[c]+=1
        else:rr[r]+=2;cc[c+1]+=2
    return tuple(rr),tuple(cc)

def canonical(tiles):return tuple(sorted(tuple(t) for t in tiles))

def tests():
    checks=0;patterns=0;tiling_count=0;multis=0
    for m in range(1,4):
        for n in range(1,4):
            for mask in range(1<<(m*n)):
                patterns+=1
                blocked=tuple((i//n,i%n) for i in range(m*n) if mask>>i&1)
                ts=all_tilings(m,n,blocked);tiling_count+=len(ts)
                groups={}
                for t in ts:groups.setdefault(clues(m,n,t),set()).add(canonical(t))
                queries=set(groups)
                queries.add(((0,)*m,(0,)*n))
                for rr,cc in list(groups):
                    r2=list(rr);c2=list(cc);r2[-1]+=1;c2[-1]+=1
                    queries.add((tuple(r2),tuple(c2)))
                for rr,cc in queries:
                    expected=groups.get((rr,cc),set());multis+=len(expected)>1
                    p=Puzzle(rr,cc,blocked)
                    for method in METHODS:
                        result=solve(p,method,None)
                        actual={canonical(t) for t in result.solutions}
                        assert result.complete and actual==expected,(m,n,blocked,rr,cc,method,expected,actual)
                        assert all(verify(p,t) for t in result.solutions)
                    checks+=1
    # Exhaust every 2x2 clue vector in [0,4], including inconsistent totals.
    ts=all_tilings(2,2,());groups={}
    for t in ts:groups.setdefault(clues(2,2,t),set()).add(canonical(t))
    for vals in itertools.product(range(5),repeat=4):
        p=Puzzle(vals[:2],vals[2:]);expected=groups.get((p.rows,p.cols),set())
        for method in METHODS:
            result=solve(p,method,None)
            assert result.complete and {canonical(t) for t in result.solutions}==expected
        checks+=1
    out=dict(board_masks=patterns,independent_tilings=tiling_count,clue_cases=checks,methods=list(METHODS),checks=checks*len(METHODS),multiple_solution_cases=multis)
    (ROOT/'test_results.json').write_text(json.dumps(out,indent=2));print('TESTS',out,flush=True)

def planted(m,n,rng,name):
    blocked={(m-1,n-1)} if m*n%2 else set()
    free={(r,c) for r in range(m) for c in range(n)}-blocked
    def rec(left,out):
        if not left:return out
        r,c=min(left);opts=[('V',(r+1,c)),('H',(r,c+1))];rng.shuffle(opts)
        for t,pair in opts:
            if pair in left:
                ans=rec(left-{(r,c),pair},out+[(t,r,c)])
                if ans is not None:return ans
        return None
    tiles=rec(free,[]);assert tiles is not None
    remove=set(rng.sample(range(len(tiles)),rng.randrange(len(tiles)//5+1)))
    keep=[]
    for i,(t,r,c) in enumerate(tiles):
        if i in remove:blocked.update(((r,c),(r+1,c) if t=='V' else (r,c+1)))
        else:keep.append((t,r,c))
    rr,cc=clues(m,n,keep);p=Puzzle(rr,cc,tuple(sorted(blocked)),name)
    assert verify(p,keep)
    return p

def percentile(xs,p):return sorted(xs)[max(0,math.ceil(len(xs)*p)-1)]

def benchmark():
    seed=20260912;rng=random.Random(seed)
    observed=[Puzzle.from_dict(d) for d in json.loads((ROOT/'observed.json').read_text())]
    generated=[planted(n,n,rng,f'planted-{n}-{i:02}') for n in (6,7,8) for i in range(20)]
    generated += [planted(n,n,rng,f'planted-{n}-{i:02}') for n in (10,12) for i in range(6)]
    (ROOT/'generated.json').write_text(json.dumps([p.to_dict() for p in generated],indent=2))
    records=[]
    for p in observed+generated:
        is_obs=p.name.startswith('observed')
        for limit,label in ((1,'first'),(2,'up-to-two')):
            for method in METHODS:
                # Three warm-up calls, then 15 repeated measurements for game
                # boards and seven for generated boards; setup is included.
                for _ in range(3):solve(p,method,limit,time_limit_s=.25)
                rs=[solve(p,method,limit,time_limit_s=.25) for _ in range(15 if is_obs else 7)]
                for r in rs:
                    assert all(verify(p,s) for s in r.solutions)
                    assert r.status=='capped' or r.solutions
                statuses=[r.status for r in rs]
                rec=dict(name=p.name,size=p.m,group='observed' if is_obs else ('synthetic' if p.m<=8 else 'stress'),mode=label,method=method,
                         median_ms=statistics.median(r.elapsed_ns/1e6 for r in rs),min_ms=min(r.elapsed_ns/1e6 for r in rs),max_ms=max(r.elapsed_ns/1e6 for r in rs),
                         nodes=rs[0].nodes,forced=rs[0].forced,cache_hits=rs[0].cache_hits,solutions=len(rs[0].solutions),complete=rs[0].complete,capped=any(s=='capped' for s in statuses))
                records.append(rec)
        print('BENCH',p.name,flush=True)
    with (ROOT/'benchmark.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    summary=[]
    for group,mode,method in itertools.product(('observed','synthetic','stress'),('first','up-to-two'),METHODS):
        rr=[r for r in records if (r['group'],r['mode'],r['method'])==(group,mode,method)]
        completed=[r for r in rr if not r['capped']]
        vals=[r['median_ms'] for r in completed]
        summary.append(dict(group=group,mode=mode,method=method,instances=len(rr),capped=sum(r['capped'] for r in rr),median_ms=statistics.median(vals) if vals else None,p95_ms=percentile(vals,.95) if vals else None,max_ms=max(vals) if vals else None,median_nodes=statistics.median(r['nodes'] for r in completed) if completed else None))
    out=dict(seed=seed,python=sys.version,platform=platform.platform(),processor=platform.processor(),clock=str(time.get_clock_info('perf_counter')),cap_seconds=.25,warmups=3,observed_repeats=15,generated_repeats=7,summary=summary)
    (ROOT/'benchmark_summary.json').write_text(json.dumps(out,indent=2))
    # Full exhaustive uniqueness certificates for the three actual boards.
    certs=[]
    for p in observed:
        r=solve(p,'margins',None);assert r.complete and len(r.solutions)==1
        certs.append(dict(puzzle=p.to_dict(),solution=[[t,a+1,b+1] for t,a,b in r.solutions[0]],nodes=r.nodes,forced=r.forced))
    (ROOT/'observed_solutions.json').write_text(json.dumps(certs,indent=2))
    print('SUMMARY',json.dumps(out,indent=2),flush=True)

if __name__=='__main__':
    if '--bench-only' not in sys.argv:tests()
    if '--test-only' not in sys.argv:benchmark()
