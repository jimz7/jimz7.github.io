"""Domino Fit exact solvers. Python 3.10+, standard library only.

Coordinates are zero based internally; blocked coordinates in Puzzle.from_dict
are one based. A vertical piece contributes one at its top; a horizontal
piece contributes two at its right. Search may stop at a solution limit.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, replace
from time import perf_counter_ns
from typing import Optional

@dataclass(frozen=True)
class Puzzle:
    rows: tuple[int, ...]
    cols: tuple[int, ...]
    blocked: tuple[tuple[int, int], ...] = ()
    name: str = "puzzle"
    @property
    def m(self): return len(self.rows)
    @property
    def n(self): return len(self.cols)
    @classmethod
    def from_dict(cls, d):
        return cls(tuple(d['rows']), tuple(d['cols']), tuple((r-1,c-1) for r,c in d.get('blocked',[])), d.get('name','puzzle'))
    def to_dict(self):
        return dict(name=self.name, rows=list(self.rows), cols=list(self.cols), blocked=[[r+1,c+1] for r,c in self.blocked])

@dataclass(frozen=True)
class Placement:
    orientation: str
    row: int
    col: int
    cells: tuple[int,int]
    mask: int
    groups: tuple[int,int]
    dots: tuple[tuple[int,int,int], ...]

@dataclass
class Result:
    status: str
    solutions: list[list[tuple[str,int,int]]]
    nodes: int
    elapsed_ns: int
    complete: bool
    cache_hits: int = 0
    forced: int = 0
    reason: str = ''

class SearchLimit(Exception): pass

class Board:
    def __init__(self, p):
        self.p=p; self.m=p.m; self.n=p.n
        if self.m < 1 or self.n < 1: raise ValueError('Dimensions must be positive')
        if any(not isinstance(x,int) or x<0 for x in p.rows+p.cols): raise ValueError('Clues must be nonnegative integers')
        if len(set(p.blocked))!=len(p.blocked) or any(not(0<=r<self.m and 0<=c<self.n) for r,c in p.blocked): raise ValueError('Invalid blocked cells')
        blocked=set(p.blocked)
        self.cells=[r*self.n+c for r in range(self.m) for c in range(self.n) if (r,c) not in blocked]
        self.full=sum(1<<i for i in self.cells)
        self.a=[sum((r,c) not in blocked for c in range(self.n)) for r in range(self.m)]
        self.b=[sum((r,c) not in blocked for r in range(self.m)) for c in range(self.n)]
        self.placements=[]; self.by_cell=[[] for _ in range(self.m*self.n)]
        self.by_group=[[] for _ in range(2*self.m+2*self.n)]
        # Groups: V start row, H row, V column, H start column.
        for r in range(self.m):
            for c in range(self.n):
                if (r,c) in blocked: continue
                i=r*self.n+c
                opts=[]
                if r+1<self.m and (r+1,c) not in blocked:
                    opts.append(Placement('V',r,c,(i,i+self.n),(1<<i)|(1<<(i+self.n)),(r,2*self.m+c),((r,c,1),)))
                if c+1<self.n and (r,c+1) not in blocked:
                    opts.append(Placement('H',r,c,(i,i+1),(1<<i)|(1<<(i+1)),(self.m+r,2*self.m+self.n+c),((r,c+1,2),)))
                for q in opts:
                    k=len(self.placements); self.placements.append(q)
                    for j in q.cells:self.by_cell[j].append(k)
                    for g in q.groups:self.by_group[g].append(k)
    def margins(self):
        p=self.p
        if len(self.cells)%2: return None,'Odd number of open cells'
        if sum(p.rows)!=sum(p.cols):return None,'Row and column clue totals differ'
        if p.rows[0]!=self.a[0]: return None,'Top row identity fails'
        vr=[self.a[r+1]-p.rows[r+1] for r in range(self.m-1)]+[0]
        hr=[]
        for r in range(self.m):
            x=p.rows[r]-vr[r]
            if x<0 or x%2:return None,'Horizontal row count is invalid'
            hr.append(x//2)
        hc=[]; vc=[]; prev=0
        for c in range(self.n):
            vc.append(p.cols[c]-2*prev)
            cur=self.b[c]-2*p.cols[c]+3*prev
            hc.append(cur); prev=cur
        targets=tuple(vr+hr+vc+hc)
        if prev!=0:return None,'Right boundary identity fails'
        if any(t<0 or t>len(self.by_group[g]) for g,t in enumerate(targets)):return None,'Orientation margin outside its geometric capacity'
        if sum(vr)!=sum(vc) or sum(hr)!=sum(hc):return None,'Orientation margin totals differ'
        return targets,''

    def add_color_margins(self, targets):
        """Split crossing quotas by starting-cell checkerboard color."""
        base=len(targets); extra=[]
        prefix=0
        for r in range(self.m):
            prefix+=sum(1 if (r+c)%2==0 else -1 for c in range(self.n) if self.full>>(r*self.n+c)&1)
            total=targets[r]
            if abs(prefix)>total or (total+prefix)%2:return None,'Row-prefix color quota fails'
            extra.extend(((total+prefix)//2,(total-prefix)//2))
        prefix=0
        for c in range(self.n):
            prefix+=sum(1 if (r+c)%2==0 else -1 for r in range(self.m) if self.full>>(r*self.n+c)&1)
            total=targets[2*self.m+self.n+c]
            if abs(prefix)>total or (total+prefix)%2:return None,'Column-prefix color quota fails'
            extra.extend(((total+prefix)//2,(total-prefix)//2))
        self.by_group.extend([] for _ in extra)
        for i,q in enumerate(self.placements):
            color=(q.row+q.col)%2
            g=base+(2*q.row if q.orientation=='V' else 2*self.m+2*q.col)+color
            self.placements[i]=replace(q,groups=q.groups+(g,))
            self.by_group[g].append(i)
        return targets+tuple(extra),''


def solve(p: Puzzle, method='bitset', solution_limit=1, time_limit_s: Optional[float]=None, node_limit: Optional[int]=None):
    """Return solutions; complete=True only when the entire search was exhausted.

    solution_limit=None enumerates all solutions. A cap returns status='capped'.
    A first solution is never a uniqueness certificate.
    """
    start=perf_counter_ns(); b=Board(p); solutions=[]; nodes=0; cache_hits=0; forced_count=0
    if solution_limit is not None and solution_limit<1:raise ValueError('solution_limit must be positive or None')
    row_masks=[sum(1<<(r*b.n+c) for c in range(b.n)) for r in range(b.m)]
    col_masks=[sum(1<<(r*b.n+c) for r in range(b.m)) for c in range(b.n)]
    deadline=start+int(time_limit_s*1e9) if time_limit_s is not None else None
    def check():
        nonlocal nodes
        nodes+=1
        if node_limit is not None and nodes>node_limit:raise SearchLimit()
        if deadline is not None and (nodes & 255)==1 and perf_counter_ns()>deadline:raise SearchLimit()
    def record(chosen):
        solutions.append([(b.placements[i].orientation,b.placements[i].row,b.placements[i].col) for i in chosen])
        return solution_limit is not None and len(solutions)>=solution_limit
    def baseline(free,rr,cc,chosen):
        check()
        if method=='residual':
            if any(x>2*(free&mask).bit_count() for x,mask in zip(rr,row_masks)):return False
            if any(x>2*(free&mask).bit_count() for x,mask in zip(cc,col_masks)):return False
        if not free:
            return record(chosen) if not any(rr) and not any(cc) else False
        cell=(free&-free).bit_length()-1
        for i in b.by_cell[cell]:
            q=b.placements[i]
            if free&q.mask!=q.mask:continue
            r,c,w=q.dots[0]
            if rr[r]<w or cc[c]<w:continue
            nr=list(rr); nc=list(cc);nr[r]-=w;nc[c]-=w
            if baseline(free^q.mask,tuple(nr),tuple(nc),chosen+[i]):return True
        return False
    failed=set()
    if method=='bitset':
        cell_bits=[sum(1<<i for i in ids) for ids in b.by_cell]
        group_bits=[sum(1<<i for i in ids) for ids in b.by_group]
        conflicts=[cell_bits[q.cells[0]]|cell_bits[q.cells[1]] for q in b.placements]
    def bitset_search(free,targets,chosen,active):
        nonlocal cache_hits,forced_count
        check();entry=(free,targets)
        if entry in failed:cache_hits+=1;return False
        n_before=len(solutions)
        while free:
            required=0
            for g,t in enumerate(targets):
                if t==0:active &= ~group_bits[g]
            for g,t in enumerate(targets):
                opts=active&group_bits[g];size=opts.bit_count()
                if t>size:failed.add(entry);return False
                if t and t==size:required|=opts
            todo=free;best=0;best_size=5
            while todo:
                bit=todo&-todo;todo^=bit;j=bit.bit_length()-1
                opts=active&cell_bits[j];size=opts.bit_count()
                if not size:failed.add(entry);return False
                if size==1:required|=opts
                if size<best_size:best,best_size=opts,size
            if required:
                nt=list(targets)
                while required:
                    bit=required&-required;required^=bit;i=bit.bit_length()-1;q=b.placements[i]
                    if not active&bit or any(nt[g]<=0 for g in q.groups):failed.add(entry);return False
                    free^=q.mask;active &= ~conflicts[i]
                    for g in q.groups:nt[g]-=1
                    chosen=chosen+[i];forced_count+=1
                targets=tuple(nt);continue
            # Exact path matching capacities for horizontal rows / vertical columns.
            for g in list(range(b.m,2*b.m))+list(range(2*b.m,2*b.m+b.n)):
                if targets[g]<=1:continue
                opts=active&group_bits[g];used=0;cap=0
                while opts:
                    bit=opts&-opts;opts^=bit;mask=b.placements[bit.bit_length()-1].mask
                    if not used&mask:used|=mask;cap+=1
                if targets[g]>cap:failed.add(entry);return False
            # Check components in the graph of currently available placements.
            unseen=free
            while unseen:
                todo=unseen&-unseen;unseen^=todo;balance=0
                while todo:
                    bit=todo&-todo;todo^=bit;j=bit.bit_length()-1;r,c=divmod(j,b.n)
                    balance+=1 if (r+c)%2==0 else -1
                    opts=active&cell_bits[j];neighbors=0
                    while opts:
                        edge=opts&-opts;opts^=edge;neighbors|=b.placements[edge.bit_length()-1].mask
                    new=neighbors&unseen;todo|=new;unseen^=new
                if balance:failed.add(entry);return False
            while best:
                bit=best&-best;best^=bit;i=bit.bit_length()-1;q=b.placements[i];nt=list(targets)
                for g in q.groups:nt[g]-=1
                if bitset_search(free^q.mask,tuple(nt),chosen+[i],active&~conflicts[i]):return True
            if len(solutions)==n_before:failed.add(entry)
            return False
        if any(targets):failed.add(entry);return False
        return record(chosen)

    def margins(free,targets,chosen):
        nonlocal cache_hits,forced_count
        check(); entry=(free,targets)
        if entry in failed:cache_hits+=1;return False
        n_before=len(solutions)
        while free:
            live=[]; cell_opts={j:[] for j in b.cells if free>>j&1}; group_opts=[[] for _ in targets]
            for i,q in enumerate(b.placements):
                if free&q.mask==q.mask and all(targets[g]>0 for g in q.groups):
                    live.append(i)
                    for j in q.cells:cell_opts[j].append(i)
                    for g in q.groups:group_opts[g].append(i)
            if any(not opts for opts in cell_opts.values()) or any(t>len(group_opts[g]) for g,t in enumerate(targets)):
                failed.add(entry);return False
            required=set(opts[0] for opts in cell_opts.values() if len(opts)==1)
            for g,t in enumerate(targets):
                if t and t==len(group_opts[g]):required.update(group_opts[g])
            if required:
                nt=list(targets)
                for i in sorted(required):
                    q=b.placements[i]
                    if free&q.mask!=q.mask or any(nt[g]<=0 for g in q.groups):failed.add(entry);return False
                    free^=q.mask
                    for g in q.groups:nt[g]-=1
                    chosen=chosen+[i];forced_count+=1
                targets=tuple(nt);continue
            # In a horizontal row or vertical column, candidates form a path.
            # Greedy earliest-edge selection computes the maximum disjoint count.
            for g in list(range(b.m,2*b.m))+list(range(2*b.m,2*b.m+b.n)):
                if targets[g]<=1:continue
                used=0; cap=0
                for i in group_opts[g]:
                    mask=b.placements[i].mask
                    if not used&mask:used|=mask;cap+=1
                if targets[g]>cap:failed.add(entry);return False
            # Every connected component of remaining open cells needs a balanced
            # checkerboard coloring. This is necessary for a domino tiling.
            unseen=free
            while unseen:
                bit=unseen&-unseen;todo=bit;unseen^=bit;balance=0
                while todo:
                    bit=todo&-todo;todo^=bit;j=bit.bit_length()-1;r,c=divmod(j,b.n)
                    balance+=1 if (r+c)%2==0 else -1
                    for k in ((j-b.n if r else -1),(j+b.n if r+1<b.m else -1),(j-1 if c else -1),(j+1 if c+1<b.n else -1)):
                        if k>=0 and (unseen>>k)&1:unseen^=1<<k;todo|=1<<k
                if balance:failed.add(entry);return False
            # Minimum remaining values, deterministic tight-margin tie break.
            opts=min(cell_opts.values(),key=lambda ids:(len(ids),sum(len(group_opts[g])-targets[g] for i in ids for g in b.placements[i].groups)))
            opts=sorted(opts,key=lambda i:sum(len(group_opts[g])-targets[g] for g in b.placements[i].groups))
            for i in opts:
                q=b.placements[i];nt=list(targets)
                for g in q.groups:nt[g]-=1
                if margins(free^q.mask,tuple(nt),chosen+[i]):return True
            if len(solutions)==n_before:failed.add(entry)
            return False
        if any(targets):failed.add(entry);return False
        return record(chosen)
    reason=''; stopped=False; capped=False
    try:
        if method in ('baseline','residual'):
            if len(b.cells)%2 or sum(p.rows)!=sum(p.cols):reason='Inconsistent parity or clue totals'
            else:stopped=baseline(b.full,p.rows,p.cols,[])
        elif method in ('margins','colored','bitset'):
            targets,reason=b.margins()
            if targets is not None and method=='colored':targets,reason=b.add_color_margins(targets)
            if targets is not None:
                if method=='bitset':stopped=bitset_search(b.full,targets,[],(1<<len(b.placements))-1)
                else:stopped=margins(b.full,targets,[])
        else:raise ValueError('Unknown method')
    except SearchLimit:capped=True
    return Result('capped' if capped else ('solved' if solutions else 'unsatisfiable'),solutions,nodes,perf_counter_ns()-start,not(stopped or capped),cache_hits,forced_count,reason)


def verify(p: Puzzle, solution):
    """Independent direct check of cells and dot clues; does not use margins."""
    blocked=set(p.blocked); occupied=set();rr=[0]*p.m;cc=[0]*p.n
    for orientation,r,c in solution:
        if orientation=='V':cells=[(r,c),(r+1,c)];dr,dc,w=r,c,1
        elif orientation=='H':cells=[(r,c),(r,c+1)];dr,dc,w=r,c+1,2
        else:return False
        for cell in cells:
            if not(0<=cell[0]<p.m and 0<=cell[1]<p.n) or cell in blocked or cell in occupied:return False
            occupied.add(cell)
        rr[dr]+=w;cc[dc]+=w
    return len(occupied)+len(blocked)==p.m*p.n and tuple(rr)==p.rows and tuple(cc)==p.cols

if __name__=='__main__':
    import argparse,json
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('puzzle',help='JSON puzzle file')
    parser.add_argument('--method',choices=['baseline','residual','margins','colored','bitset'],default='bitset')
    parser.add_argument('--limit',type=int,default=1,help='Solution limit; 0 enumerates all')
    parser.add_argument('--seconds',type=float)
    args=parser.parse_args()
    with open(args.puzzle,encoding='utf8') as f:p=Puzzle.from_dict(json.load(f))
    result=solve(p,args.method,args.limit or None,args.seconds)
    assert all(verify(p,s) for s in result.solutions)
    print(json.dumps(asdict(result),indent=2))
