# Domino Fit research package

This package accompanies the 12-page report **Domino Fit as Constrained Perfect Matching: Exact Models, Cut Invariants, and a Practical Solver** (September 12, 2026).

## Contents

- `paper/`: the supplied blank LaTeX article template, completed with the research. Its article class, one-inch margins, section structure, and bibliography style are retained.
- `solver/domino_fit.py`: exact solver and independent direct verifier; Python 3.10+, standard library only.
- `solver/experiments.py`: exhaustive checks and seeded benchmark generation.
- `solver/observed.json`, `example8.json`: the actual game boards transcribed from the visible play session.
- `solver/generated.json`: the 72 nonuniform planted instances used in the measurements.
- `solver/observed_solutions.json`: one-based solution certificates; all three boards are unique.
- `solver/benchmark.csv`, `benchmark_summary.json`, `test_results.json`: measured results and environment.
- `tools/build_assets.py`: optional figure/table regeneration; requires ReportLab.
- `manifest.json`: SHA-256 checksums for the packaged sources and data.

## Run

From `solver/`:

```sh
python domino_fit.py example8.json --method bitset --limit 1
python domino_fit.py example8.json --method bitset --limit 2
python domino_fit.py example8.json --method bitset --limit 0
python experiments.py --test-only
python experiments.py
```

`--limit 0` means enumerate all. `--seconds` supplies a soft resource limit. The API default and CLI default are the bitset solver. Four compared methods are `residual`, `margins`, `colored`, and `bitset`; the simpler `baseline` mode is not in the paper's timing tables.

Input blocked-cell coordinates are one based. Solver output placements are `[orientation, row, column]` with zero-based start coordinates. Orientation `V` means top 1, bottom 0; `H` means left 0, right 2. `observed_solutions.json` instead uses one-based starts for convenient reading.

Interpret `complete` and solution count together: one solution without exhaustion is not a uniqueness certificate. Two solutions prove nonuniqueness. A capped search never proves infeasibility. The verifier checks original dots and coverage, independently of margin inversion.

Experiments rewrite generated data and result files. The distribution is nonuniform and planted satisfiable; it is not the actual game generator. Timings include in-memory model construction and search, but exclude file I/O, external verification and UI operation. Exact times vary across machines and background load. The report specifies the fixed benchmark order, warmups, repetitions, and capped cases. It does not claim universal optimality, and the frontier DP is analyzed but not implemented.

## Compile

From `paper/`:

```sh
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Alternatively: `tectonic main.tex`. The delivered PDF was compiled using Tectonic 0.17.0. The prepared vector figure and table fragments are included. To regenerate those after rerunning experiments, install ReportLab and run `python tools/build_assets.py` from this package root. Regenerating tables does not automatically update numeric prose in the manuscript; review those sentences when using new timing results.

No game state or mouse controls are accessed by the solver. The package contains mathematical solving and reproducibility code, not an automated screen-reading player.
